namespace CoachCRM.Dtos
{
    public class CreateTeamDto
    {
        public string Name { get; set; } = null!;
    }

}