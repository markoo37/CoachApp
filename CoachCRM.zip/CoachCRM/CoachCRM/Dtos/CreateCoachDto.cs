namespace CoachCRM.Dtos
{
    public class CreateCoachDto
    {
        public string FirstName { get; set; } = null!;
        public string LastName { get; set; } = null!;
        public string Email { get; set; } = null!;
    }
}